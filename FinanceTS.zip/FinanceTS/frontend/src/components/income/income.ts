import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";

export class Income {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    private incomeCategories: HTMLElement | null = document.getElementById('income-categories');
    readonly insertBeforeElement: HTMLElement | null = document.getElementById('add-category');
    private popupElement: HTMLElement | null = document.getElementById('popup');
    private categoryId: number | null = null;
    readonly incomeDeleteCategoryButton: HTMLElement | null = document.getElementById('income-delete-category');
    readonly closePopupButton: HTMLElement | null = document.getElementById('income-delete-category-cancel');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);

        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        this.getIncomeCategories().then();
        if (this.closePopupButton) {
            this.closePopupButton.addEventListener('click', this.closePopup.bind(this));
        }
        if(this.incomeDeleteCategoryButton) {
            this.incomeDeleteCategoryButton.addEventListener('click', this.deleteCategory.bind(this));
        }
    }
    private async getIncomeCategories(): Promise<Response | undefined> {
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };
        const response: Response = await fetch(host + 'categories/income', params);
        const result: CategoriesResponseType[] | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });
                if (updateTokenResult && updateTokenResult.status === 200) {
                    const tokens = await updateTokenResult.json();
                    if (tokens && !tokens.error) {

                        Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }

        }
        await this.showCategories(result as CategoriesResponseType[]);
    }
    private async showCategories(categories: CategoriesResponseType[]): Promise<void> {
        for (let i = 0; i < categories.length; i++) {
            const categoryElement: HTMLElement | null = document.createElement('div');
            categoryElement.className = 'income-category col-4';
            const categoryTitleElement: HTMLElement = document.createElement('h2');
            categoryTitleElement.innerText = categories[i].title;
            categoryElement.appendChild(categoryTitleElement);
            const buttonGroupElement: HTMLElement = document.createElement('div');
            buttonGroupElement.className = 'button-group';
            buttonGroupElement.innerHTML = '<a href="/income/edit?id=' + categories[i].id + '" class="btn btn-primary me-1">Редактировать</a>\n' +
                '<a class="btn btn-danger income-category-delete-button" >Удалить</a>';
            categoryElement.appendChild(buttonGroupElement);
            if (this.insertBeforeElement && this.incomeCategories) {
                this.incomeCategories.insertBefore(categoryElement, this.insertBeforeElement);
            }
            let deleteButton: any = document.querySelectorAll('.income-category-delete-button')[i];
            deleteButton.addEventListener('click', this.openPopup.bind(this));
            deleteButton.category_id = categories[i].id;
        }
    }

    private openPopup(e:any): void {
        e.preventDefault();
        if (this.popupElement) {
            this.popupElement.style.display = 'block';
        }
        this.categoryId = e.currentTarget.category_id;
    }

    private closePopup(e:MouseEvent): void {
        e.preventDefault();
        if (this.popupElement) {
            this.popupElement.style.display = 'none';
        }
    }

    private deleteCategory(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/income/delete?id=' + this.categoryId);
    }
}