import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";


export class ExpensesDelete {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
        const urlId = urlParams.get('id');
        if (urlId) {
            const id: number | null = parseInt(urlId) ;
            if (!id) {
                return this.openNewRoute('/');
            }
            this.deleteExpenseCategory(id).then();
        }
    }
    private async deleteExpenseCategory(id:number): Promise<Response> {
        const params: RequestInit = {
            method: 'DELETE',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        }
        const response: Response = await fetch(host + 'categories/expense/' + id, params);
        const result: CategoriesResponseType | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });

                if (updateTokenResult.status === 200) {
                    const tokens = await updateTokenResult.json();

                    if (tokens && !tokens.error) {
                        Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }
        }
        return this.openNewRoute('/expense');
    }

}