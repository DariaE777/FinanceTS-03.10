export type BalanceResponseType = {
    balance: number
}