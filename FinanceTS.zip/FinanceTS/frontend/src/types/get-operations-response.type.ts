export type GetOperationsResponseType = {
    id: number,
    type: string,
    category: string,
    amount: number,
    date: string,
    comment: string
}

export type GetOperationsDataType = {
    category_id: number,
    type: string,
    category: string,
    amount: number,
    date: string,
    comment: string
}