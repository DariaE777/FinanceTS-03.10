import {DataType} from "./data.type";
import {OptionsType} from "./options.type";
import {MarginPluginType} from "./margin-plugin.type";

export type ConfigType = {
    type: string,
    data: DataType,
    options: OptionsType,
    plugins: [MarginPluginType]
}