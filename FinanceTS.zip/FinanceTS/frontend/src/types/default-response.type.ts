export type DefaultResponseType = {
    error: boolean,
    message: string
}